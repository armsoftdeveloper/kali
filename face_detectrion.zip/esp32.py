# import serial
# import time

# # Set the port name and baud rate to match your ESP32 configuration
# port = "COM4"  # Update the port name (COMx on Windows)
# baud_rate = 115200

# ser = serial.Serial(port, baud_rate, timeout=1)

# try:
#     while True:
#         # Send data to ESP32
#         data_to_send = "Hello from Python\n"
#         ser.write(data_to_send.encode('utf-8'))

#         # Read data from ESP32
#         received_data = ser.readline().decode('utf-8').rstrip()
#         print(f"Received from ESP32: {received_data}")

#         time.sleep(1)

# except KeyboardInterrupt:
#     ser.close()
#     print("Serial connection closed.")


import serial
import cv2
import numpy as np

# Set the port name and baud rate to match your ESP32 configuration
port = "COM4"  # Update the port name (COMx on Windows)
baud_rate = 115200

ser = serial.Serial(port, baud_rate, timeout=1)

try:
    while True:
        # Read image size
        image_size = int(ser.readline().decode('utf-8').split(":")[1])

        # Read image data
        image_data = ser.read(image_size)

        # Convert the byte array to a NumPy array
        nparr = np.frombuffer(image_data, np.uint8)

        # Decode the image using OpenCV
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        # Display the image
        cv2.imshow("ESP32 Camera", img)

        # Break the loop on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    ser.close()
    print("Serial connection closed.")
finally:
    cv2.destroyAllWindows()
