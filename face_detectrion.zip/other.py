import cv2
import serial
import numpy as np

ser = serial.Serial('COM4', 115200, timeout=1)
width, height = 160, 120  # Set the width and height based on your camera resolution
channels = 3

def read_image_from_serial():
    image_data = ser.read(width * height * channels)
    return image_data

def display_live_video():
    while True:
        image_data = read_image_from_serial()
        frame = np.frombuffer(image_data, dtype=np.uint8).reshape((height, width, channels))
        cv2.imshow('Live Video', frame)

        if cv2.waitKey(1) == 27:  # Break the loop on 'Esc' key press
            break

try:
    display_live_video()

except KeyboardInterrupt:
    ser.close()
    cv2.destroyAllWindows()
