import cv2
import pyfirmata2
import pygame
import time
from colorama import Fore, Back, Style, init
init(autoreset=True)

def play_sound():
    sound_file = "alarm.mp3"  # Replace with the path to your sound file
    pygame.mixer.init()
    pygame.mixer.music.load(sound_file)
    pygame.mixer.music.play()

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

video = cv2.VideoCapture(0)

board = pyfirmata2.Arduino('COM4')

# Set pin 13 as OUTPUT
led_pin = board.get_pin('d:13:o')

while True:
    check , frame = video.read()
    faces = face_cascade.detectMultiScale(frame,scaleFactor=1.1,minNeighbors=5)

    for x , y , w , h in faces:
        frame = cv2.rectangle(frame , (x,y) , (x+w,y+h), (0,255,0),3)

    cv2.imshow('Face Detector' , frame)

    key = cv2.waitKey(1)

    if key == ord('q'):
        break
    
    if len(faces) > 0:
        print(Fore.RED + "WARNING: People detected! Take appropriate action. !")

        led_pin.write(1)
        time.sleep(0.1)
        # Turn off the LED
        led_pin.write(0)
        time.sleep(0.1)
        board.digital[13].write(0)
    else:
        board.digital[13].write(1)
        print(Fore.GREEN + "All is Okay  , No People Around. !")
        print("All is Okay  , No People Around. !")
        play_sound()


video.release()
cv2.destroyAllWindows()
board = pyfirmata2.Arduino('COM4')

while True:
    board.digital[13].write(1)
    time.sleep(1)
    board.digital[13].write(0)
    time.sleep(1)