import pyfirmata2
import time

board = pyfirmata2.Arduino('COM4')

while True:
    board.digital[13].write(1)
    time.sleep(1)
    board.digital[13].write(0)
    time.sleep(1)



# from pyfirmata2 import Arduino, util
# import time

# # Specify the COM port for your Arduino
# # Replace 'COM4' with the actual COM port of your Arduino
# arduino_port = 'COM4'

# # Create an Arduino board object
# board = Arduino(arduino_port)

# # Define an iterator to avoid buffer overflow
# it = util.Iterator(board)
# it.start()

# # Set up the digital pin 13 (LED on most Arduino boards)
# led_pin = board.get_pin('d:13:o')

# # Your code to interact with the Arduino goes here
# try:
#     while True:
#         led_pin.write(1)  # Turn on the LED
#         time.sleep(1)
#         led_pin.write(0)  # Turn off the LED
#         time.sleep(1)

# except KeyboardInterrupt:
#     # Close the connection when the script is interrupted
#     board.exit()


